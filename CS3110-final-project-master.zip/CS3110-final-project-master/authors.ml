let hx_hours_worked = 40

let slt_hours_worked = 40

let zh_hours_worked = 40

let kz_hours_worked = 40
